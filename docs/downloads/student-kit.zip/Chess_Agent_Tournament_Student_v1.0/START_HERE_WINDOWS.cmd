@echo off
setlocal
cd /d "%~dp0"

where uv >nul 2>nul
if errorlevel 1 (
  echo uv is required but was not found.
  echo Install it from https://docs.astral.sh/uv/getting-started/installation/
  pause
  exit /b 1
)

echo Preparing the local project environment...
uv sync --frozen
if errorlevel 1 (
  echo Environment setup failed. Review the message above.
  pause
  exit /b 1
)

uv run python -m chess_student_app
if errorlevel 1 pause

