# Tools and Dependencies

The student package uses one environment manager and one third-party Python library.

| Item | Version | Purpose |
|---|---:|---|
| CPython | 3.12.13 | Pinned official Python runtime |
| uv | Current supported release | Creates the local environment and installs the lock file |
| chess | 1.11.2 | Board representation, legal moves, adjudication, and PGN |

`.python-version` pins the interpreter and `uv.lock` pins Python packages. Do not distribute or reuse a `.venv` from another computer. The launchers create the environment in the extracted student folder.
