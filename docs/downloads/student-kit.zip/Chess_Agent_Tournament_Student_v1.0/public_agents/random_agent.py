from __future__ import annotations

import random

import chess

from chess_tournament_api import ChessAgent, Observation


class RandomAgent(ChessAgent):
    """Public legality baseline that chooses a seeded random move."""

    name = "Random"

    def initialize(self, *, color, opponent_id, time_control, seed) -> None:
        self._rng = random.Random(seed)

    def choose_move(self, observation: Observation) -> str:
        board = chess.Board(observation.fen)
        moves = sorted(board.legal_moves, key=lambda move: move.uci())
        return self._rng.choice(moves).uci()

