from __future__ import annotations

import chess

from chess_tournament_api import ChessAgent, Observation


PIECE_VALUE = {
    chess.PAWN: 1,
    chess.KNIGHT: 3,
    chess.BISHOP: 3,
    chess.ROOK: 5,
    chess.QUEEN: 9,
    chess.KING: 100,
}


class GreedyAgent(ChessAgent):
    """Public one-ply baseline that prefers immediate material gain."""

    name = "Greedy"

    def choose_move(self, observation: Observation) -> str:
        board = chess.Board(observation.fen)
        ranked: list[tuple[int, str, chess.Move]] = []
        for move in board.legal_moves:
            victim = board.piece_at(move.to_square)
            captured_value = PIECE_VALUE.get(victim.piece_type, 0) if victim else 0
            board.push(move)
            mate_bonus = 10_000 if board.is_checkmate() else 0
            check_bonus = 1 if board.is_check() else 0
            board.pop()
            ranked.append((mate_bonus + 10 * captured_value + check_bonus, move.uci(), move))
        ranked.sort(key=lambda item: (-item[0], item[1]))
        return ranked[0][2].uci()

