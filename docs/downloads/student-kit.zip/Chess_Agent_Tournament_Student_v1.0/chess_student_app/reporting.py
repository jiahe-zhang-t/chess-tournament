from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import chess


def _csv_safe(value: object) -> object:
    if isinstance(value, str) and value.startswith(("=", "+", "-", "@")):
        return "'" + value
    return value


def _board_squares(board: chess.Board) -> list[str]:
    """Return exactly 64 symbols in visual rank-8-to-rank-1 order."""

    squares: list[str] = []
    for rank in range(7, -1, -1):
        for file_index in range(8):
            piece = board.piece_at(chess.square(file_index, rank))
            squares.append(piece.symbol() if piece else "")
    return squares


_PIECE_NAMES = {
    chess.PAWN: "Pawn",
    chess.KNIGHT: "Knight",
    chess.BISHOP: "Bishop",
    chess.ROOK: "Rook",
    chess.QUEEN: "Queen",
    chess.KING: "King",
}

_TERMINATION_LABELS = {
    "checkmate": "Checkmate",
    "stalemate": "Stalemate",
    "insufficient_material": "Draw by insufficient material",
    "seventyfive_moves": "Draw by the 75-move rule",
    "fivefold_repetition": "Draw by fivefold repetition",
    "fifty_moves": "Draw by the 50-move rule",
    "threefold_repetition": "Repeated position",
    "maximum_plies": "Move limit reached",
    "clock_timeout": "Time expired",
    "choose_move_timeout": "Move decision timed out",
    "choose_move_exception": "Agent error while choosing a move",
    "initialize_timeout": "Agent setup timed out",
    "initialize_exception": "Agent error during setup",
    "invalid_output": "Agent returned an invalid move",
    "illegal_move": "Agent returned an illegal move",
    "double_forfeit": "Both agents forfeited",
    "unknown_adjudication": "Game ended without an adjudicated result",
    "worker_protocol": "Agent communication error",
    "worker_exit": "Agent process stopped unexpectedly",
    "startup_timeout": "Agent startup timed out",
}


def _safe_basename(value: str | Path | None, fallback: str) -> str:
    """Return a display-only basename without exposing a local path."""

    if value is None:
        return fallback
    name = str(value).replace("\\", "/").rsplit("/", 1)[-1].strip()
    name = "".join(character for character in name if character.isprintable()).strip()
    if not name or name in {".", ".."}:
        return fallback
    return name[:255]


def _termination_label(code: object) -> str:
    if not isinstance(code, str):
        return "Game ended for an unrecognized reason"
    return _TERMINATION_LABELS.get(code, "Game ended for an unrecognized reason")


def _move_description(board: chess.Board, move: chess.Move) -> tuple[str, dict[str, Any]]:
    side = "White" if board.turn == chess.WHITE else "Black"
    piece = board.piece_at(move.from_square)
    piece_name = _PIECE_NAMES.get(piece.piece_type, "Piece") if piece else "Piece"
    from_square = chess.square_name(move.from_square)
    to_square = chess.square_name(move.to_square)
    is_capture = board.is_capture(move)
    is_castling = board.is_castling(move)
    captured_piece = board.piece_at(move.to_square)
    if board.is_en_passant(move):
        captured_piece = chess.Piece(chess.PAWN, not board.turn)

    if is_castling:
        flank = "kingside" if chess.square_file(move.to_square) > chess.square_file(move.from_square) else "queenside"
        description = f"{side} {piece_name} castles {flank} from {from_square} to {to_square}"
    else:
        description = f"{side} {piece_name} moves from {from_square} to {to_square}"
        if is_capture:
            if captured_piece is None:
                description += " and captures a piece"
            else:
                captured_color = "White" if captured_piece.color == chess.WHITE else "Black"
                description += f" and captures {captured_color} {_PIECE_NAMES[captured_piece.piece_type]}"
        if move.promotion:
            description += f" and promotes to {_PIECE_NAMES[move.promotion]}"

    next_board = board.copy(stack=False)
    next_board.push(move)
    is_checkmate = next_board.is_checkmate()
    is_check = next_board.is_check()
    if is_checkmate:
        description += ". Checkmate."
    elif is_check:
        description += ". Check."
    else:
        description += "."

    return description, {
        "from_square": from_square,
        "to_square": to_square,
        "is_capture": is_capture,
        "is_check": is_check,
        "is_checkmate": is_checkmate,
        "is_castling": is_castling,
        "promotion": _PIECE_NAMES.get(move.promotion) if move.promotion else None,
    }


def _positions(result: dict[str, Any]) -> list[dict[str, Any]]:
    board = chess.Board(result["starting_fen"])
    starting_side = "White" if board.turn == chess.WHITE else "Black"
    positions = [
        {
            "label": "Start",
            "ply": 0,
            "side": starting_side,
            "side_to_move": starting_side,
            "fullmove_number": board.fullmove_number,
            "san": "",
            "description": f"Starting position. {starting_side} to move on move {board.fullmove_number}.",
            "from_square": None,
            "to_square": None,
            "is_capture": False,
            "is_check": board.is_check(),
            "is_checkmate": board.is_checkmate(),
            "is_castling": False,
            "promotion": None,
            "fen": board.fen(),
            "squares": _board_squares(board),
        }
    ]
    for index, uci in enumerate(result["moves"], start=1):
        move = chess.Move.from_uci(uci)
        side = "White" if board.turn == chess.WHITE else "Black"
        fullmove_number = board.fullmove_number
        san = board.san(move)
        description, move_metadata = _move_description(board, move)
        board.push(move)
        label = f"{fullmove_number}. {san}" if side == "White" else f"{fullmove_number}... {san}"
        positions.append(
            {
                "label": label,
                "ply": index,
                "side": side,
                "side_to_move": "White" if board.turn == chess.WHITE else "Black",
                "fullmove_number": fullmove_number,
                "san": san,
                "description": description,
                **move_metadata,
                "fen": board.fen(),
                "squares": _board_squares(board),
            }
        )
    return positions


def _student_move_seconds(record: dict[str, Any], student_id: str) -> list[float]:
    """Extract student-only move times from new or legacy controller records."""

    callbacks = record.get("move_callbacks")
    if isinstance(callbacks, list):
        return [
            float(item["elapsed_seconds"])
            for item in callbacks
            if isinstance(item, dict)
            and item.get("agent_id") == student_id
            and isinstance(item.get("elapsed_seconds"), (int, float))
        ]

    # Compatibility for records written before move_callbacks carried agent IDs.
    result = record["result"]
    if student_id == result.get("white_id"):
        student_color = chess.WHITE
    elif student_id == result.get("black_id"):
        student_color = chess.BLACK
    else:
        return []
    starting_turn = chess.Board(result["starting_fen"]).turn
    values: list[float] = []
    for index, elapsed in enumerate(record.get("move_times", [])):
        callback_color = starting_turn if index % 2 == 0 else not starting_turn
        if callback_color == student_color:
            values.append(float(elapsed))
    return values


def write_local_report(
    records: list[dict[str, Any]],
    *,
    output_root: str | Path,
    student_id: str = "agent-a",
    student_filename: str | Path | None = None,
    opponent_filename: str | Path | None = None,
) -> Path:
    now = datetime.now(timezone.utc)
    run_id = now.strftime("%Y%m%dT%H%M%SZ") + "-" + records[0]["result"]["match_id"][:8]
    destination = Path(output_root).resolve() / run_id
    suffix = 2
    while destination.exists():
        destination = Path(output_root).resolve() / f"{run_id}-{suffix}"
        suffix += 1
    pgn_dir = destination / "pgn"
    pgn_dir.mkdir(parents=True)

    wins = draws = losses = faults = 0
    points = 0.0
    student_move_times: list[float] = []
    public_games: list[dict[str, Any]] = []
    first_result = records[0]["result"]
    first_student_is_white = first_result.get("white_id") == student_id
    first_student_alias = (
        first_result.get("white_alias") if first_student_is_white else first_result.get("black_alias")
    )
    first_opponent_alias = (
        first_result.get("black_alias") if first_student_is_white else first_result.get("white_alias")
    )
    student_display_name = _safe_basename(
        student_filename, _safe_basename(first_student_alias, "Student agent")
    )
    opponent_display_name = _safe_basename(
        opponent_filename, _safe_basename(first_opponent_alias, "Practice opponent")
    )

    for game_number, record in enumerate(records, start=1):
        result = record["result"]
        if result.get("white_id") == student_id:
            student_is_white = True
        elif result.get("black_id") == student_id:
            student_is_white = False
        else:
            raise ValueError(f"student_id {student_id!r} is not present in game {result.get('game_id')!r}")
        score = result["white_score"] if student_is_white else result["black_score"]
        opponent_score = result["black_score"] if student_is_white else result["white_score"]
        if result.get("termination_code") == "double_forfeit":
            student_outcome = "Loss"
        elif score > opponent_score:
            student_outcome = "Win"
        elif score < opponent_score:
            student_outcome = "Loss"
        else:
            student_outcome = "Draw"
        points += score
        wins += int(student_outcome == "Win")
        draws += int(student_outcome == "Draw")
        losses += int(student_outcome == "Loss")
        faults += int(result["fault_agent_id"] == student_id)
        faults += sum(1 for item in record["hook_faults"] if item["agent_id"] == student_id)
        game_student_move_times = _student_move_seconds(record, student_id)
        student_move_times.extend(game_student_move_times)
        pgn_name = f"{result['game_id']}.pgn"
        (pgn_dir / pgn_name).write_text(result["pgn"], encoding="utf-8")
        item = dict(result)
        item.pop("pgn", None)
        item["positions"] = _positions(result)
        item["pgn_path"] = f"pgn/{pgn_name}"
        item["student_move_seconds"] = game_student_move_times
        item["hook_faults"] = record["hook_faults"]
        item["student_filename"] = student_display_name
        item["opponent_filename"] = opponent_display_name
        item["student_color"] = "White" if student_is_white else "Black"
        item["opponent_color"] = "Black" if student_is_white else "White"
        item["student_score"] = score
        item["opponent_score"] = opponent_score
        item["student_outcome"] = student_outcome
        match_game_index = int(result.get("match_game_index") or game_number)
        item["round_number"] = (max(1, match_game_index) + 1) // 2
        item["termination_label"] = _termination_label(result.get("termination_code"))
        item["student_final_time"] = result["white_time"] if student_is_white else result["black_time"]
        item["opponent_final_time"] = result["black_time"] if student_is_white else result["white_time"]
        if result.get("fault_agent_id") == student_id:
            item["fault_display_name"] = student_display_name
        elif result.get("fault_agent_id") in {result.get("white_id"), result.get("black_id")}:
            item["fault_display_name"] = opponent_display_name
        elif result.get("fault_agent_id"):
            item["fault_display_name"] = "An agent"
        else:
            item["fault_display_name"] = None
        public_games.append(item)

    summary = {
        "run_id": destination.name,
        "generated_at": now.isoformat(),
        "label": "Local Test Results",
        "student_agent_id": student_id,
        "student_filename": student_display_name,
        "opponent_filename": opponent_display_name,
        "games_played": len(records),
        "wins": wins,
        "draws": draws,
        "losses": losses,
        "points": points,
        "score_percentage": points / len(records) if records else 0.0,
        "faults": faults,
        "timing_scope": "student_agent_only",
        "student_move_count": len(student_move_times),
        "student_average_move_seconds": (
            sum(student_move_times) / len(student_move_times) if student_move_times else 0.0
        ),
        "student_maximum_move_seconds": max(student_move_times, default=0.0),
        # Compatibility aliases retained for existing local-report consumers.
        "average_callback_seconds": (
            sum(student_move_times) / len(student_move_times) if student_move_times else 0.0
        ),
        "maximum_callback_seconds": max(student_move_times, default=0.0),
        "games": public_games,
    }
    (destination / "summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    with (destination / "games.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream)
        writer.writerow(("game_id", "white", "black", "result", "termination", "fault_agent_id", "seed"))
        for item in public_games:
            writer.writerow(
                tuple(
                    _csv_safe(value)
                    for value in (
                        item["game_id"],
                        item["white_alias"],
                        item["black_alias"],
                        item["result"],
                        item["termination_code"],
                        item["fault_agent_id"] or "",
                        item["seed"],
                    )
                )
            )

    encoded = json.dumps(summary, ensure_ascii=True).replace("<", "\\u003c").replace(">", "\\u003e").replace("&", "\\u0026")
    html = REPORT_TEMPLATE.replace("__REPORT_DATA__", encoded)
    report_path = destination / "local_report.html"
    report_path.write_text(html, encoding="utf-8")
    return report_path


REPORT_TEMPLATE = r'''<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline';">
  <title>Chess Agent Match Report</title>
  <style>
    :root{font-family:Inter,Segoe UI,Arial,sans-serif;color:#172033;background:#f4f7fb}*{box-sizing:border-box}body{margin:0;padding:32px}.wrap{max-width:1100px;margin:auto}.eyebrow{color:#486581;font-size:13px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}h1{font-size:34px;margin:8px 0 4px}.matchup{font-size:20px;font-weight:700;margin:0 0 8px;overflow-wrap:anywhere}.sub{color:#5c6b7a;margin:0 0 24px}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px}.card,.panel{background:#fff;border:1px solid #d9e2ec;border-radius:12px;box-shadow:0 8px 24px rgba(20,38,63,.06)}.card{padding:16px}.value{font-size:26px;font-weight:750;margin-top:6px}.panel{padding:20px;margin-top:18px}.games{display:grid;gap:10px}.game{display:flex;gap:16px;align-items:center;justify-content:space-between;padding:14px;border:1px solid #e3eaf2;border-radius:9px;background:#fff}.game-copy{display:grid;gap:4px;min-width:0}.game-name{font-weight:750;overflow-wrap:anywhere}.game-detail{color:#526273;font-size:14px}.actions{display:flex;gap:10px;align-items:center;flex-shrink:0}.replay-button{border:0;border-radius:8px;background:#193b68;color:#fff;padding:10px 18px;font-size:15px;font-weight:750;cursor:pointer}.replay-button:hover{background:#102f55}.replay-button:focus-visible,.controls button:focus-visible,.timeline input:focus-visible{outline:3px solid #83b8ff;outline-offset:2px}.pgn-link{color:#486581;font-size:13px}.replay{display:grid;grid-template-columns:360px minmax(0,1fr);gap:28px}.board{display:grid;grid-template-columns:repeat(8,1fr);width:100%;max-width:360px;border:1px solid #65758b}.sq{aspect-ratio:1;min-width:0;display:flex;align-items:center;justify-content:center;font-size:30px}.light{background:#e8edf2}.dark{background:#7791ad}.timeline{width:100%;max-width:360px;margin:14px 0 8px}.timeline label{display:flex;justify-content:space-between;color:#526273;font-size:13px;font-weight:700}.timeline input{width:100%;margin:9px 0 0}.controls{display:flex;gap:8px;width:100%;max-width:360px}.controls button{flex:1;padding:9px 12px;border:1px solid #b8c5d4;border-radius:7px;background:#fff;color:#193b68;font-weight:700;cursor:pointer}.controls button:disabled{color:#8b98a8;background:#f0f3f7;cursor:not-allowed}.replay>div{min-width:0}.move-san{font-size:22px;font-weight:750;margin:8px 0}.move-description{color:#405166;line-height:1.5;min-height:1.5em}.meta{white-space:pre-wrap;overflow-wrap:anywhere;font-family:ui-monospace,Consolas,monospace;font-size:13px;line-height:1.6}.empty{color:#66788a}@media(max-width:760px){body{padding:18px}.game{align-items:flex-start;flex-direction:column}.actions{width:100%;justify-content:flex-end}.replay{grid-template-columns:1fr}.board,.timeline,.controls{max-width:100%}}
  </style>
</head>
<body><main class="wrap">

  <h1>Match Report</h1>
  <p class="matchup" id="matchup"></p>
  <p class="sub">Practice results only. Official results are calculated after submission.</p>
  <section class="cards" id="cards"></section>
  <section class="panel"><h2>Games</h2><div class="games" id="games"></div></section>
  <section class="panel replay"><div><h2>Replay</h2><div class="board" id="board" role="img" aria-label="Chess board"></div><div class="timeline"><label for="move-slider"><output id="ply-count">Move 0 of 0</output></label><input id="move-slider" type="range" min="0" max="0" value="0" step="1" aria-label="Replay position"></div><div class="controls"><button type="button" id="prev">Previous</button><button type="button" id="next">Next</button></div></div><div><h2 id="replay-title">Select a game</h2><div class="move-san" id="move-san" aria-live="polite">Starting position</div><p class="move-description" id="move-description"></p><div class="meta" id="replay-meta"></div></div></section>
</main>
<script id="report-data" type="application/json">__REPORT_DATA__</script>
<script>
const data=JSON.parse(document.getElementById('report-data').textContent);
const sessionToken=new URLSearchParams(location.search).get('token')||'';
const slider=document.getElementById('move-slider');
const previousButton=document.getElementById('prev');
const nextButton=document.getElementById('next');
let selected=null,ply=0;
function gameTitle(g){const white=g.student_color==='White'?g.student_filename:g.opponent_filename;const black=g.student_color==='Black'?g.student_filename:g.opponent_filename;return `R${g.round_number} · ${white} (White) vs ${black} (Black)`}
document.getElementById('matchup').textContent=`${data.student_filename} vs ${data.opponent_filename}`;
const cards=[['Games',data.games_played],['Wins · Draws · Losses',`${data.wins}-${data.draws}-${data.losses}`],['Score',`${(100*data.score_percentage).toFixed(1)}%`],['Errors',data.faults],['Average move time',`${data.student_average_move_seconds.toFixed(4)}s`],['Longest move time',`${data.student_maximum_move_seconds.toFixed(4)}s`]];
for(const [label,value] of cards){const card=document.createElement('div');card.className='card';const l=document.createElement('div');l.textContent=label;const v=document.createElement('div');v.className='value';v.textContent=value;card.append(l,v);document.getElementById('cards').append(card)}
data.games.forEach((g,i)=>{const row=document.createElement('div');row.className='game';const copy=document.createElement('div');copy.className='game-copy';const name=document.createElement('div');name.className='game-name';name.textContent=gameTitle(g);const detail=document.createElement('div');detail.className='game-detail';detail.textContent=`${g.student_outcome} · ${g.termination_label}`;copy.append(name,detail);const actions=document.createElement('span');actions.className='actions';const button=document.createElement('button');button.type='button';button.className='replay-button';button.textContent='Replay';button.setAttribute('aria-label',`Replay R${g.round_number}, student plays ${g.student_color}`);button.addEventListener('click',()=>loadGame(i));const pgn=document.createElement('a');pgn.className='pgn-link';pgn.textContent='PGN';pgn.href=`${g.pgn_path}${sessionToken?`?token=${encodeURIComponent(sessionToken)}`:''}`;pgn.download='';actions.append(button,pgn);row.append(copy,actions);document.getElementById('games').append(row)});
const pieces={p:'♟',r:'♜',n:'♞',b:'♝',q:'♛',k:'♚',P:'♙',R:'♖',N:'♘',B:'♗',Q:'♕',K:'♔'};
function draw(squares){const board=document.getElementById('board');board.textContent='';if(!Array.isArray(squares)||squares.length!==64){board.textContent='Replay data error';return}squares.forEach((piece,index)=>{const row=Math.floor(index/8),file=index%8;const sq=document.createElement('div');sq.className=`sq ${(row+file)%2?'dark':'light'}`;sq.textContent=pieces[piece]||'';board.append(sq)})}
function render(){if(selected===null)return;const g=data.games[selected],maxPly=g.positions.length-1,p=g.positions[ply];draw(p.squares);document.getElementById('board').setAttribute('aria-label',`Chess board at ${p.label}`);document.getElementById('replay-title').textContent=`R${g.round_number} · Game ${selected+1}`;document.getElementById('move-san').textContent=p.san?`${p.side} · ${p.fullmove_number}${p.side==='Black'?'...':'.'} ${p.san}`:'Starting position';document.getElementById('move-description').textContent=p.description;slider.max=String(maxPly);slider.disabled=maxPly===0;slider.value=String(ply);slider.setAttribute('aria-valuetext',p.label);document.getElementById('ply-count').textContent=`Move ${ply} of ${maxPly}`;previousButton.disabled=ply===0;nextButton.disabled=ply===maxPly;const lines=[`${g.student_outcome} · ${g.termination_label}`,`White: ${g.student_color==='White'?g.student_filename:g.opponent_filename}`,`Black: ${g.student_color==='Black'?g.student_filename:g.opponent_filename}`,`Final time: White ${Number(g.white_time).toFixed(2)}s · Black ${Number(g.black_time).toFixed(2)}s`];if(g.fault_display_name)lines.push(`Error: ${g.fault_display_name}`);document.getElementById('replay-meta').textContent=lines.join('\n')}
function loadGame(i){selected=i;ply=0;slider.value='0';document.getElementById('move-san').textContent='Starting position';document.getElementById('move-description').textContent='';render()}
previousButton.addEventListener('click',()=>{if(selected!==null){ply=Math.max(0,ply-1);render()}});
nextButton.addEventListener('click',()=>{if(selected!==null){ply=Math.min(data.games[selected].positions.length-1,ply+1);render()}});
slider.addEventListener('input',()=>{if(selected!==null){ply=Number(slider.value);render()}});
document.addEventListener('keydown',event=>{if(event.target===slider||['INPUT','SELECT','TEXTAREA'].includes(event.target.tagName)||event.altKey||event.ctrlKey||event.metaKey)return;if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();if(selected!==null){const step=event.key==='ArrowLeft'?-1:1;ply=Math.max(0,Math.min(data.games[selected].positions.length-1,ply+step));render()}}});
if(data.games.length){loadGame(0)}else{document.getElementById('games').textContent='No games were recorded.';slider.disabled=true;previousButton.disabled=true;nextButton.disabled=true}
</script></body></html>'''
