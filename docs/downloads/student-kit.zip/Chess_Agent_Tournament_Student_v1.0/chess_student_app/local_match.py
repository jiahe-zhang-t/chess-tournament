from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from .controller import GameConfig, LocalEndpoint, WorkerEndpoint, play_game, stable_id
from public_agents import GreedyAgent, RandomAgent


@dataclass(slots=True)
class EndpointSlot:
    factory: Callable[[], object]
    endpoint: object | None = None

    def get(self):
        if self.endpoint is None or not self.endpoint.alive:
            if self.endpoint is not None:
                self.endpoint.close()
            self.endpoint = self.factory()
        return self.endpoint

    def close(self) -> None:
        if self.endpoint is not None:
            self.endpoint.close()
            self.endpoint = None


def _public_factory(name: str):
    if name == "random":
        return lambda: LocalEndpoint(RandomAgent())
    if name == "greedy":
        return lambda: LocalEndpoint(GreedyAgent())
    raise ValueError(f"unknown public opponent: {name}")


def run_local_matchup(
    agent_path: str | Path,
    *,
    opponent: str = "greedy",
    opponent_path: str | Path | None = None,
    games: int = 4,
    base_seed: int = 20260904,
    config: GameConfig | None = None,
) -> list[dict]:
    if games < 1 or games > 100:
        raise ValueError("games must be between 1 and 100")
    agent_path = Path(agent_path).resolve(strict=True)
    config = config or GameConfig()
    agent_digest = hashlib.sha256(agent_path.read_bytes()).hexdigest()
    opponent_identity = str(opponent_path or opponent)
    if opponent_path is not None:
        resolved_opponent = Path(opponent_path).resolve(strict=True)
        opponent_identity = hashlib.sha256(resolved_opponent.read_bytes()).hexdigest()
    match_id = stable_id("local", agent_digest, opponent_identity, base_seed)
    first = EndpointSlot(lambda: WorkerEndpoint(str(agent_path)))
    if opponent_path is not None:
        second = EndpointSlot(lambda: WorkerEndpoint(str(resolved_opponent)))
    else:
        second = EndpointSlot(_public_factory(opponent))

    records: list[dict] = []
    color_pattern = (True, False, False, True)
    try:
        for index in range(1, games + 1):
            student_is_white = color_pattern[(index - 1) % len(color_pattern)]
            a = first.get()
            b = second.get()
            if student_is_white:
                white, black = a, b
                white_id, black_id = "agent-a", "agent-b"
                white_opp, black_opp = "opponent-b", "opponent-a"
            else:
                white, black = b, a
                white_id, black_id = "agent-b", "agent-a"
                white_opp, black_opp = "opponent-a", "opponent-b"
            record = play_game(
                white,
                black,
                white_id=white_id,
                black_id=black_id,
                white_opponent_id=white_opp,
                black_opponent_id=black_opp,
                match_id=match_id,
                match_game_index=index,
                seed=base_seed + index,
                config=config,
            )
            record["local_roles"] = {
                "student_agent_id": "agent-a",
                "opponent_agent_id": "agent-b",
            }
            records.append(record)
    finally:
        first.close()
        second.close()
    return records
