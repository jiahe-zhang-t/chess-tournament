from __future__ import annotations

import argparse
import json
from pathlib import Path

from .local_match import run_local_matchup
from .reporting import write_local_report
from .validation import format_validation, validate_agent


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Chess Agent Test Space command line")
    subparsers = parser.add_subparsers(dest="command", required=True)
    validate = subparsers.add_parser("validate", help="validate one agent file")
    validate.add_argument("agent")
    validate.add_argument("--json", action="store_true", dest="as_json")

    match = subparsers.add_parser("match", help="run a local matchup")
    match.add_argument("--agent", required=True)
    match.add_argument("--opponent", choices=("random", "greedy"), default="greedy")
    match.add_argument("--opponent-file")
    match.add_argument("--games", type=int, default=4)
    match.add_argument("--output", default="local_runs")
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.command == "validate":
        result = validate_agent(args.agent)
        print(json.dumps(result, indent=2) if args.as_json else format_validation(result))
        # The two bundled examples are allowed to serve as installation smoke
        # tests, but their output explicitly says they are not submission-ready.
        development_example_ok = result["development_example"] and result["development_passed"]
        return 0 if result["submission_ready"] or development_example_ok else 1

    records = run_local_matchup(
        args.agent,
        opponent=args.opponent,
        opponent_path=args.opponent_file,
        games=args.games,
    )
    report = write_local_report(
        records,
        output_root=Path(args.output),
        student_filename=Path(args.agent).name,
        opponent_filename=(
            Path(args.opponent_file).name if args.opponent_file else f"{args.opponent}_agent.py"
        ),
    )
    print(f"Local report: {report}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
