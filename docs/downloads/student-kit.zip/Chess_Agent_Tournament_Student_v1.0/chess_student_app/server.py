from __future__ import annotations

import argparse
import json
import os
import secrets
import threading
import webbrowser
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

from .local_match import run_local_matchup
from .reporting import write_local_report
from .validation import MAX_FILE_BYTES, format_validation, validate_agent


PACKAGE_ROOT = Path(__file__).resolve().parents[1]
WORKSPACE = PACKAGE_ROOT / "workspace"
RUNS = PACKAGE_ROOT / "local_runs"
STATIC = Path(__file__).resolve().parent / "static"


def _safe_child(root: Path, relative: str) -> Path:
    candidate = (root / unquote(relative)).resolve()
    if candidate == root.resolve() or root.resolve() not in candidate.parents:
        raise ValueError("path escapes the allowed folder")
    return candidate


class LabServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, handler, token: str) -> None:
        super().__init__(address, handler)
        self.token = token
        self.run_lock = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    server: LabServer

    def log_message(self, format: str, *args) -> None:
        print(f"[local-app] {self.address_string()} {format % args}")

    def _token_ok(self, query: dict[str, list[str]] | None = None) -> bool:
        supplied = self.headers.get("X-Session-Token", "")
        if not supplied and query:
            supplied = (query.get("token") or [""])[0]
        return secrets.compare_digest(supplied, self.server.token)

    def _send_bytes(
        self,
        data: bytes,
        content_type: str,
        status: int = 200,
        *,
        content_security_policy: str = "default-src 'self'; style-src 'self'; script-src 'self'",
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Content-Security-Policy", content_security_policy)
        self.end_headers()
        self.wfile.write(data)

    def _json(self, value, status: int = 200) -> None:
        self._send_bytes(
            json.dumps(value, ensure_ascii=False).encode("utf-8"),
            "application/json; charset=utf-8",
            status,
        )

    def _read_json(self) -> dict:
        length = int(self.headers.get("Content-Length", "0"))
        if length < 1 or length > 64 * 1024:
            raise ValueError("invalid request size")
        return json.loads(self.rfile.read(length))

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        query = parse_qs(parsed.query)
        try:
            if parsed.path in ("/", "/index.html"):
                return self._send_bytes((STATIC / "index.html").read_bytes(), "text/html; charset=utf-8")
            if parsed.path == "/app.js":
                return self._send_bytes((STATIC / "app.js").read_bytes(), "text/javascript; charset=utf-8")
            if parsed.path == "/style.css":
                return self._send_bytes((STATIC / "style.css").read_bytes(), "text/css; charset=utf-8")
            if parsed.path == "/api/status":
                if not self._token_ok(query):
                    return self._json({"error": "invalid session token"}, HTTPStatus.FORBIDDEN)
                WORKSPACE.mkdir(parents=True, exist_ok=True)
                agents = sorted(path.name for path in WORKSPACE.glob("*.py") if path.is_file())
                return self._json(
                    {
                        "python": os.sys.version.split()[0],
                        "workspace": str(WORKSPACE),
                        "agents": agents,
                    }
                )
            if parsed.path.startswith("/runs/"):
                if not self._token_ok(query):
                    return self._send_bytes(b"Forbidden", "text/plain", HTTPStatus.FORBIDDEN)
                target = _safe_child(RUNS, parsed.path.removeprefix("/runs/"))
                if not target.is_file():
                    return self._send_bytes(b"Not found", "text/plain", HTTPStatus.NOT_FOUND)
                content_type = "text/html; charset=utf-8" if target.suffix == ".html" else "text/plain; charset=utf-8"
                if target.suffix == ".html":
                    return self._send_bytes(
                        target.read_bytes(),
                        content_type,
                        content_security_policy=(
                            "default-src 'none'; style-src 'unsafe-inline'; "
                            "script-src 'unsafe-inline'"
                        ),
                    )
                return self._send_bytes(target.read_bytes(), content_type)
            return self._send_bytes(b"Not found", "text/plain", HTTPStatus.NOT_FOUND)
        except (OSError, ValueError) as exc:
            self._json({"error": str(exc)}, HTTPStatus.BAD_REQUEST)

    def do_POST(self) -> None:
        parsed = urlparse(self.path)
        if not self._token_ok(parse_qs(parsed.query)):
            return self._json({"error": "invalid session token"}, HTTPStatus.FORBIDDEN)
        try:
            if parsed.path == "/api/upload":
                name = Path(self.headers.get("X-Filename", "")).name
                if not name.endswith(".py") or name in {".py", ""}:
                    raise ValueError("upload must be one .py file")
                length = int(self.headers.get("Content-Length", "0"))
                if length < 1 or length > MAX_FILE_BYTES:
                    raise ValueError(f"file must be between 1 and {MAX_FILE_BYTES} bytes")
                body = self.rfile.read(length)
                WORKSPACE.mkdir(parents=True, exist_ok=True)
                target = _safe_child(WORKSPACE, name)
                temporary = target.with_suffix(".py.uploading")
                temporary.write_bytes(body)
                temporary.replace(target)
                return self._json({"ok": True, "filename": target.name})

            payload = self._read_json()
            name = Path(str(payload.get("agent", ""))).name
            source = _safe_child(WORKSPACE, name)
            if source.suffix != ".py" or not source.is_file():
                raise ValueError("select an existing .py file from the workspace")
            if parsed.path == "/api/validate":
                result = validate_agent(source)
                result.pop("games", None)
                result["text"] = format_validation(result)
                return self._json(result)
            if parsed.path == "/api/run":
                opponent = str(payload.get("opponent", "greedy"))
                games = int(payload.get("games", 4))
                if opponent not in {"random", "greedy"}:
                    raise ValueError("opponent must be random or greedy")
                if not self.server.run_lock.acquire(blocking=False):
                    return self._json({"error": "another local match is running"}, HTTPStatus.CONFLICT)
                try:
                    records = run_local_matchup(source, opponent=opponent, games=games)
                    report = write_local_report(
                        records,
                        output_root=RUNS,
                        student_filename=source.name,
                        opponent_filename=f"{opponent}_agent.py",
                    )
                finally:
                    self.server.run_lock.release()
                relative = report.relative_to(RUNS).as_posix()
                return self._json(
                    {
                        "ok": True,
                        "report_url": f"/runs/{relative}?token={self.server.token}",
                        "report_path": str(report),
                        "games_played": len(records),
                    }
                )
            return self._json({"error": "unknown endpoint"}, HTTPStatus.NOT_FOUND)
        except Exception as exc:
            return self._json({"error": f"{type(exc).__name__}: {exc}"}, HTTPStatus.BAD_REQUEST)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Chess Agent Test Space")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--no-browser", action="store_true")
    args = parser.parse_args(argv)
    token = secrets.token_urlsafe(24)
    WORKSPACE.mkdir(parents=True, exist_ok=True)
    RUNS.mkdir(parents=True, exist_ok=True)
    server = LabServer(("127.0.0.1", args.port), Handler, token)
    port = server.server_address[1]
    url = f"http://127.0.0.1:{port}/?token={token}"
    print(f"Chess Agent Test Space: {url}")
    print("Press Ctrl+C to stop.")
    if not args.no_browser:
        threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping local app.")
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
