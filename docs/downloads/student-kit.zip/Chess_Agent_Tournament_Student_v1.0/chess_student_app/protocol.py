from __future__ import annotations

import json
import re
from typing import Any

MAX_REQUEST_BYTES = 2 * 1024 * 1024
MAX_RESPONSE_BYTES = 64 * 1024
MAX_MOVE_BYTES = 32
ALIAS_PATTERN = re.compile(r"[A-Za-z0-9][A-Za-z0-9 ._-]{0,39}\Z")


def encode_message(message: dict[str, Any]) -> bytes:
    data = json.dumps(message, ensure_ascii=True, separators=(",", ":")).encode("utf-8")
    if len(data) > MAX_RESPONSE_BYTES:
        raise ValueError("protocol response exceeds the byte limit")
    return data + b"\n"


def safe_error(exc: BaseException) -> str:
    message = " ".join(str(exc).split())
    return f"{type(exc).__name__}: {message}"[:500]


def validate_alias(value: object) -> str:
    if type(value) is not str:
        raise TypeError("agent name must be a plain string")
    alias = value.strip()
    if not ALIAS_PATTERN.fullmatch(alias):
        raise ValueError(
            "agent name must be 1-40 ASCII letters, digits, spaces, periods, underscores, or hyphens"
        )
    return alias

