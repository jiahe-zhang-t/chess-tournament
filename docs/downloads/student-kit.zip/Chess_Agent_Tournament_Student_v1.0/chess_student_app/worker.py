from __future__ import annotations

import argparse
import importlib.util
import inspect
import io
import json
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

from chess_tournament_api import API_VERSION, ChessAgent, GameResult, Observation

from .protocol import MAX_MOVE_BYTES, MAX_REQUEST_BYTES, encode_message, safe_error, validate_alias


class BoundedTextBuffer(io.TextIOBase):
    def __init__(self, limit: int = 8192) -> None:
        self.limit = limit
        self._text = ""

    def writable(self) -> bool:
        return True

    def write(self, text: str) -> int:
        value = str(text)
        remaining = max(0, self.limit - len(self._text))
        if remaining:
            self._text += value[:remaining]
        return len(value)

    def drain(self) -> str:
        value = self._text
        self._text = ""
        return value


def _send(stream, message: dict[str, Any]) -> None:
    stream.write(encode_message(message))
    stream.flush()


def _load_agent(source: Path) -> tuple[ChessAgent, str, str]:
    module_name = f"student_submission_{source.stem}"
    spec = importlib.util.spec_from_file_location(module_name, source)
    if spec is None or spec.loader is None:
        raise ImportError("could not create an import specification")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        sys.modules.pop(module_name, None)
        raise

    classes = _eligible_classes(module)
    if len(classes) != 1:
        raise ValueError(f"exactly one ChessAgent subclass is required; found {len(classes)}")
    agent = classes[0]()
    alias = validate_alias(getattr(agent, "name", ""))
    return agent, alias, classes[0].__name__


def _eligible_classes(module: ModuleType) -> list[type[ChessAgent]]:
    found: list[type[ChessAgent]] = []
    for value in vars(module).values():
        if (
            inspect.isclass(value)
            and value is not ChessAgent
            and issubclass(value, ChessAgent)
            and value.__module__ == module.__name__
        ):
            found.append(value)
    return found


def _handle(agent: ChessAgent, request: dict[str, Any]) -> Any:
    action = request.get("action")
    payload = request.get("payload") or {}
    if action == "initialize":
        agent.initialize(
            color=str(payload["color"]),
            opponent_id=str(payload["opponent_id"]),
            time_control=(float(payload["time_control"][0]), float(payload["time_control"][1])),
            seed=int(payload["seed"]),
        )
        return None
    if action == "choose_move":
        move = agent.choose_move(Observation.from_dict(payload["observation"]))
        if type(move) is not str:
            raise TypeError("choose_move must return a plain Python string")
        if len(move.encode("utf-8", errors="replace")) > MAX_MOVE_BYTES:
            raise ValueError("move response is too large")
        return move
    if action == "game_end":
        agent.on_game_end(GameResult.from_dict(payload["result"]))
        return None
    if action == "shutdown":
        return "shutdown"
    raise ValueError(f"unknown action: {action!r}")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--agent", required=True)
    args = parser.parse_args(argv)

    protocol_out = sys.stdout.buffer
    captured = BoundedTextBuffer()
    sys.stdout = captured
    sys.stderr = captured

    try:
        source = Path(args.agent).resolve(strict=True)
        agent, alias, class_name = _load_agent(source)
        _send(
            protocol_out,
            {
                "id": 0,
                "ok": True,
                "data": {"alias": alias, "class_name": class_name, "api_version": API_VERSION},
                "logs": captured.drain(),
            },
        )
    except BaseException as exc:
        _send(protocol_out, {"id": 0, "ok": False, "error": safe_error(exc), "logs": captured.drain()})
        return 2

    while True:
        line = sys.stdin.buffer.readline(MAX_REQUEST_BYTES + 1)
        if not line:
            return 0
        if len(line) > MAX_REQUEST_BYTES:
            _send(protocol_out, {"id": -1, "ok": False, "error": "request_too_large"})
            return 3
        request_id = -1
        try:
            request = json.loads(line)
            request_id = int(request["id"])
            data = _handle(agent, request)
            _send(
                protocol_out,
                {"id": request_id, "ok": True, "data": data, "logs": captured.drain()},
            )
            if request.get("action") == "shutdown":
                return 0
        except BaseException as exc:
            _send(
                protocol_out,
                {
                    "id": request_id,
                    "ok": False,
                    "error": safe_error(exc),
                    "logs": captured.drain(),
                },
            )


if __name__ == "__main__":
    raise SystemExit(main())

