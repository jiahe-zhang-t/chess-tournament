"""Local student development application."""

