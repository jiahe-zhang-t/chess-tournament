const params = new URLSearchParams(location.search);
const token = params.get('token') || '';
const main = document.querySelector('main');
const fileInput = document.getElementById('file');
const agentSelect = document.getElementById('agent');
const uploadStatus = document.getElementById('upload-status');
const busyStatus = document.getElementById('busy');
const results = document.getElementById('results');
const resultsTitle = document.getElementById('results-title');
const output = document.getElementById('output');
const reportCard = document.getElementById('report-card');
const reportSummary = document.getElementById('report-summary');
const report = document.getElementById('report');
const controls = [...document.querySelectorAll('button, input, select')];

const checkCopy = {
  python_file: ['File type', 'Use one Python file ending in .py.'],
  file_size: ['File size', 'Keep the file at or below 1 MiB.'],
  syntax: ['Python code', 'Fix the Python syntax error, then run validation again.'],
  dependencies: ['Libraries', 'Use only the libraries allowed for this project.'],
  filename: ['File name', 'Rename the file to YOUR_NETID.py before submitting.'],
  load_and_construct: ['Agent starts', 'Make sure the file defines one ChessAgent that can start.'],
  games_vs_random: ['Random test', 'Your agent did not complete the Random test.'],
  games_vs_greedy: ['Greedy test', 'Your agent did not complete the Greedy test.'],
  seeded_replay: ['Repeat test', 'Your agent must make the same choices when it receives the same seed.'],
};

function setBusy(on, label = '') {
  controls.forEach((control) => {
    control.disabled = on;
  });
  main.setAttribute('aria-busy', String(on));
  busyStatus.textContent = on ? label : '';
}

async function api(path, options = {}) {
  options.headers = {...(options.headers || {}), 'X-Session-Token': token};
  const response = await fetch(path, options);
  let data = {};
  try {
    data = await response.json();
  } catch {
    data = {};
  }
  if (!response.ok) {
    throw new Error(data.error || `HTTP ${response.status}`);
  }
  return data;
}

function baseName(value) {
  const parts = String(value || '').split(/[\\/]/);
  return parts[parts.length - 1] || 'Selected file';
}

function technicalDetails(text) {
  if (!text) return null;
  const details = document.createElement('details');
  details.className = 'technical-details';
  const summary = document.createElement('summary');
  summary.textContent = 'Technical Details';
  const pre = document.createElement('pre');
  pre.textContent = String(text);
  details.append(summary, pre);
  return details;
}

function hideReport() {
  reportCard.hidden = true;
  reportSummary.textContent = '';
  report.removeAttribute('href');
}

function clearResults() {
  results.hidden = true;
  output.replaceChildren();
  hideReport();
}

function showResults(title, content) {
  resultsTitle.textContent = title;
  output.replaceChildren(content);
  results.hidden = false;
}

function showFriendlyError(title, message, diagnostic = '') {
  const content = document.createDocumentFragment();
  const paragraph = document.createElement('p');
  paragraph.className = 'friendly-error';
  paragraph.textContent = message;
  content.append(paragraph);
  const details = technicalDetails(diagnostic);
  if (details) content.append(details);
  showResults(title, content);
}

function fallbackCheckLabel(name) {
  return String(name || 'Check')
    .replaceAll('_', ' ')
    .replace(/\b\w/g, (letter) => letter.toUpperCase());
}

function friendlyFailure(check) {
  const detail = String(check.detail || '').toLowerCase();
  if (check.name === 'syntax') {
    const line = detail.match(/line (\d+)/);
    if (line) return `Fix the Python syntax near line ${line[1]}, then run validation again.`;
  }
  if (detail.includes('illegal_move')) return 'Your agent returned an illegal move during this test.';
  if (detail.includes('invalid_output')) return 'Your agent returned a move in the wrong format.';
  if (detail.includes('timeout') || detail.includes('took too long')) return 'Your agent took too long during this test.';
  return (checkCopy[check.name] || [null, 'This check did not pass.'])[1];
}

function renderValidation(data) {
  const content = document.createDocumentFragment();
  const fileLine = document.createElement('p');
  fileLine.className = 'file-line';
  fileLine.textContent = `File: ${baseName(data.submission || agentSelect.value)}`;
  content.append(fileLine);

  const list = document.createElement('ul');
  list.className = 'check-list';
  for (const check of Array.isArray(data.checks) ? data.checks : []) {
    const passed = Boolean(check.passed);
    const item = document.createElement('li');
    item.className = `check-item ${passed ? 'check-pass' : 'check-fail'}`;

    const badge = document.createElement('span');
    badge.className = 'check-badge';
    badge.textContent = passed ? 'PASS' : 'FAIL';

    const label = document.createElement('span');
    label.className = 'check-label';
    label.textContent = (checkCopy[check.name] || [fallbackCheckLabel(check.name)])[0];
    item.append(badge, label);

    if (!passed) {
      const message = document.createElement('p');
      message.className = 'check-message';
      message.textContent = friendlyFailure(check);
      item.append(message);
    }
    list.append(item);
  }
  content.append(list);

  const outcome = document.createElement('div');
  outcome.className = 'validation-outcome';
  const outcomeTitle = document.createElement('strong');
  const outcomeMessage = document.createElement('span');
  if (data.submission_ready) {
    outcome.classList.add('outcome-ready');
    outcomeTitle.textContent = 'READY TO SUBMIT';
    outcomeMessage.textContent = 'Your file passed every validation check.';
  } else if (data.development_passed) {
    outcome.classList.add('outcome-not-ready');
    outcomeTitle.textContent = 'NOT READY TO SUBMIT';
    outcomeMessage.textContent = 'Rename the file to YOUR_NETID.py, then validate it again.';
  } else {
    outcome.classList.add('outcome-failed');
    outcomeTitle.textContent = 'NEEDS CHANGES';
    outcomeMessage.textContent = 'Fix the items marked FAIL, then run validation again.';
  }
  outcome.append(outcomeTitle, outcomeMessage);
  content.append(outcome);

  const details = data.submission_ready ? null : technicalDetails(data.text || JSON.stringify(data, null, 2));
  if (details) content.append(details);
  showResults('Validation Results', content);
}

async function refreshFiles({showError = true} = {}) {
  try {
    const data = await api('/api/status');
    const current = agentSelect.value;
    agentSelect.textContent = '';
    if (!Array.isArray(data.agents) || data.agents.length === 0) {
      const option = document.createElement('option');
      option.value = '';
      option.textContent = 'No agent files yet';
      agentSelect.append(option);
    } else {
      data.agents.forEach((name) => {
        const option = document.createElement('option');
        option.value = name;
        option.textContent = name;
        agentSelect.append(option);
      });
      if (data.agents.includes(current)) agentSelect.value = current;
    }
    return {ok: true};
  } catch (error) {
    if (showError) {
      showFriendlyError(
        'Files Could Not Load',
        'Restart the Test Space, then try again.',
        error instanceof Error ? error.message : String(error),
      );
    }
    return {ok: false, error};
  }
}

fileInput.addEventListener('change', () => {
  uploadStatus.textContent = '';
  clearResults();
});
agentSelect.addEventListener('change', () => {
  uploadStatus.textContent = '';
  clearResults();
});
document.getElementById('opponent').addEventListener('change', hideReport);
document.getElementById('games').addEventListener('input', hideReport);

document.getElementById('refresh').addEventListener('click', async () => {
  clearResults();
  setBusy(true, 'Loading files…');
  await refreshFiles();
  setBusy(false);
});

document.getElementById('upload').addEventListener('click', async () => {
  clearResults();
  uploadStatus.textContent = '';
  const file = fileInput.files[0];
  if (!file) {
    uploadStatus.textContent = 'Choose one .py file first.';
    return;
  }

  setBusy(true, 'Adding file…');
  try {
    const data = await api('/api/upload', {
      method: 'POST',
      headers: {'X-Filename': file.name, 'Content-Type': 'application/octet-stream'},
      body: await file.arrayBuffer(),
    });
    uploadStatus.textContent = `Added ${baseName(data.filename)}`;
    const refreshed = await refreshFiles({showError: false});
    if (refreshed.ok) {
      agentSelect.value = data.filename;
    } else {
      showFriendlyError(
        'File Added',
        'Your file was added, but the file list could not be reloaded. Use Reload files to try again.',
        refreshed.error instanceof Error ? refreshed.error.message : String(refreshed.error),
      );
    }
  } catch (error) {
    uploadStatus.textContent = 'File not added.';
    showFriendlyError(
      'File Could Not Be Added',
      'Choose one .py file at or below 1 MiB, then try again.',
      error instanceof Error ? error.message : String(error),
    );
  } finally {
    setBusy(false);
  }
});

document.getElementById('validate').addEventListener('click', async () => {
  const agent = agentSelect.value;
  clearResults();
  if (!agent) {
    showFriendlyError('Choose a File', 'Choose an agent file in Step 2 first.');
    return;
  }

  setBusy(true, 'Checking your file…');
  try {
    const data = await api('/api/validate', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({agent}),
    });
    renderValidation(data);
  } catch (error) {
    showFriendlyError(
      'Validation Could Not Finish',
      'Check your file, then run validation again.',
      error instanceof Error ? error.message : String(error),
    );
  } finally {
    setBusy(false);
  }
});

document.getElementById('run').addEventListener('click', async () => {
  const agent = agentSelect.value;
  const requestedGames = Number(document.getElementById('games').value);
  clearResults();
  if (!agent) {
    showFriendlyError('Choose a File', 'Choose an agent file in Step 2 first.');
    return;
  }

  if (!Number.isInteger(requestedGames) || requestedGames < 1 || requestedGames > 100) {
    showFriendlyError('Choose the Number of Games', 'Enter a whole number from 1 to 100.');
    return;
  }
  setBusy(true, 'Running test games…');
  try {
    const data = await api('/api/run', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        agent,
        opponent: document.getElementById('opponent').value,
        games: requestedGames,
      }),
    });
    const reportUrl = new URL(data.report_url, window.location.href);
    if (reportUrl.origin !== window.location.origin || !reportUrl.pathname.startsWith('/runs/')) {
      throw new Error('The report URL returned by the Test Space was not valid.');
    }
    const reportedGames = Number(data.games_played);
    const gamesFinished = Number.isInteger(reportedGames) && reportedGames >= 0
      ? reportedGames
      : requestedGames;
    reportSummary.textContent = `${gamesFinished} ${gamesFinished === 1 ? 'game' : 'games'} finished.`;
    report.href = reportUrl.href;
    reportCard.hidden = false;
  } catch (error) {
    showFriendlyError(
      'Test Could Not Finish',
      'Check your agent, then run the test again.',
      error instanceof Error ? error.message : String(error),
    );
  } finally {
    setBusy(false);
  }
});

refreshFiles();
