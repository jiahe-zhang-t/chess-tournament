from __future__ import annotations

import json
import os
import queue
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Any

from .protocol import MAX_REQUEST_BYTES, MAX_RESPONSE_BYTES


class AgentProcessError(RuntimeError):
    def __init__(self, category: str, message: str) -> None:
        super().__init__(message)
        self.category = category


class AgentProcess:
    """Bounded JSON-line RPC client for a single student Agent worker."""

    def __init__(self, source: str | Path, *, startup_timeout: float = 2.0) -> None:
        self.source = Path(source).resolve(strict=True)
        self._responses: queue.Queue[dict[str, Any]] = queue.Queue()
        self._stderr = bytearray()
        self._next_id = 1
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP if os.name == "nt" else 0
        env = os.environ.copy()
        env["PYTHONHASHSEED"] = "0"
        app_root = Path(__file__).resolve().parents[1]
        self.process = subprocess.Popen(
            [sys.executable, "-m", "chess_student_app.worker", "--agent", str(self.source)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            # The student kit deliberately uses ``package = false``.  Launch
            # from the kit root so the worker module remains importable even
            # when the submitted file lives under ``workspace/``.
            cwd=str(app_root),
            env=env,
            creationflags=creationflags,
        )
        assert self.process.stdout is not None
        assert self.process.stderr is not None
        self._stdout_thread = threading.Thread(target=self._read_stdout, daemon=True)
        self._stderr_thread = threading.Thread(target=self._read_stderr, daemon=True)
        self._stdout_thread.start()
        self._stderr_thread.start()

        response = self._wait_response(startup_timeout, "import_timeout")
        if not response.get("ok"):
            self.kill()
            raise AgentProcessError("load_error", str(response.get("error", "worker load failed")))
        data = response.get("data") or {}
        self.alias = str(data["alias"])
        self.class_name = str(data["class_name"])
        self.api_version = str(data["api_version"])

    @property
    def alive(self) -> bool:
        return self.process.poll() is None

    def _read_stdout(self) -> None:
        assert self.process.stdout is not None
        while True:
            line = self.process.stdout.readline(MAX_RESPONSE_BYTES + 1)
            if not line:
                return
            if len(line) > MAX_RESPONSE_BYTES:
                self._responses.put({"ok": False, "error": "response_too_large"})
                self.kill()
                return
            try:
                message = json.loads(line.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                self._responses.put({"ok": False, "error": "invalid_worker_protocol"})
                self.kill()
                return
            self._responses.put(message)

    def _read_stderr(self) -> None:
        assert self.process.stderr is not None
        while True:
            block = self.process.stderr.read(1024)
            if not block:
                return
            remaining = 8192 - len(self._stderr)
            if remaining > 0:
                self._stderr.extend(block[:remaining])

    def _wait_response(self, timeout: float, timeout_category: str) -> dict[str, Any]:
        try:
            return self._responses.get(timeout=max(0.001, timeout))
        except queue.Empty as exc:
            self.kill()
            raise AgentProcessError(timeout_category, f"worker did not respond within {timeout:.3f}s") from exc

    def rpc(self, action: str, payload: dict[str, Any], *, timeout: float) -> tuple[Any, float, str]:
        if not self.alive:
            raise AgentProcessError("worker_exit", "worker is not running")
        request_id = self._next_id
        self._next_id += 1
        message = json.dumps(
            {"id": request_id, "action": action, "payload": payload},
            ensure_ascii=True,
            separators=(",", ":"),
        ).encode("utf-8") + b"\n"
        if len(message) > MAX_REQUEST_BYTES:
            raise AgentProcessError("request_too_large", "controller request exceeds the protocol limit")
        assert self.process.stdin is not None
        started = time.monotonic()
        try:
            self.process.stdin.write(message)
            self.process.stdin.flush()
        except (BrokenPipeError, OSError) as exc:
            self.kill()
            raise AgentProcessError("worker_exit", "worker exited before accepting the callback") from exc
        response = self._wait_response(timeout, f"{action}_timeout")
        elapsed = time.monotonic() - started
        if int(response.get("id", -1)) != request_id:
            self.kill()
            raise AgentProcessError("protocol_error", "worker response ID did not match the request")
        if not response.get("ok"):
            raise AgentProcessError(f"{action}_exception", str(response.get("error", "callback failed")))
        return response.get("data"), elapsed, str(response.get("logs", ""))

    def kill(self) -> None:
        if self.process.poll() is None:
            self.process.kill()
            try:
                self.process.wait(timeout=1.0)
            except subprocess.TimeoutExpired:
                pass

    def close(self) -> None:
        if self.alive:
            try:
                self.rpc("shutdown", {}, timeout=0.25)
            except AgentProcessError:
                pass
        self.kill()

    def __enter__(self) -> "AgentProcess":
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()
