from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any, ClassVar

from .version import API_VERSION


@dataclass(frozen=True, slots=True)
class Observation:
    """Immutable information supplied to an agent for one move."""

    fen: str
    move_history: tuple[str, ...]
    my_remaining_time: float
    opponent_remaining_time: float
    increment: float
    color: str
    opponent_id: str
    match_game_index: int
    seed: int

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["move_history"] = list(self.move_history)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Observation":
        return cls(
            fen=str(data["fen"]),
            move_history=tuple(str(move) for move in data["move_history"]),
            my_remaining_time=float(data["my_remaining_time"]),
            opponent_remaining_time=float(data["opponent_remaining_time"]),
            increment=float(data["increment"]),
            color=str(data["color"]),
            opponent_id=str(data["opponent_id"]),
            match_game_index=int(data["match_game_index"]),
            seed=int(data["seed"]),
        )


@dataclass(frozen=True, slots=True)
class GameResult:
    """Identity-safe, recipient-relative result passed to ``on_game_end``."""

    game_id: str
    opponent_id: str
    my_color: str
    outcome: str
    my_score: float
    opponent_score: float
    termination_code: str
    fault_side: str | None
    moves: tuple[str, ...]
    my_remaining_time: float
    opponent_remaining_time: float
    starting_fen: str
    seed: int
    match_game_index: int

    def to_dict(self) -> dict[str, Any]:
        data = asdict(self)
        data["moves"] = list(self.moves)
        return data

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "GameResult":
        values = dict(data)
        values["moves"] = tuple(str(move) for move in values.get("moves", ()))
        return cls(**values)


class ChessAgent:
    """Base class implemented by every student agent."""

    api_version: ClassVar[str] = API_VERSION
    name: ClassVar[str] = "unnamed-agent"

    def initialize(
        self,
        *,
        color: str,
        opponent_id: str,
        time_control: tuple[float, float],
        seed: int,
    ) -> None:
        """Optional callback at the beginning of each game."""

    def choose_move(self, observation: Observation) -> str:
        """Return one legal move in UCI notation."""
        raise NotImplementedError

    def on_game_end(self, result: GameResult) -> None:
        """Optional bounded callback after a completed game."""

    def metadata(self) -> dict[str, str]:
        return {
            "api_version": self.api_version,
            "name": self.name,
            "class": type(self).__name__,
        }
