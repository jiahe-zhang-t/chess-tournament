# Chess Agent Test Space

Build and test your chess agent on your own computer. Practice results are shown here; official results are calculated after submission.

## Start on Windows

1. Install `uv` from the official Astral documentation if it is not already installed.
2. Extract the ZIP to a normal writable folder.
3. Double-click `START_HERE_WINDOWS.cmd`.

The first launch installs the interpreter pinned by `.python-version`, creates `.venv` inside this folder, and installs the exact packages in `uv.lock`. Later launches reuse that environment.

## Start on macOS or Linux

```bash
chmod +x START_HERE_MACOS_LINUX.sh
./START_HERE_MACOS_LINUX.sh
```

## Develop and submit

Copy `workspace/TEMPLATE_agent.py` to `workspace/YOUR_NETID.py` and edit it in your usual code editor. In Chess Agent Test Space, follow the four steps: Add Your Agent, Choose the Agent to Test, Validate Your Agent, and Run Test Games. After the games finish, select **View Game Report** to see results and drag through the replay. Submit only the final `YOUR_NETID.py` file through Gradescope.

The template can be used to check your installation. Before submitting, use your actual NetID as the filename and confirm that the web page shows `READY TO SUBMIT`. The CLI reports the same successful check as `PASSED — SUBMISSION READY`.

## CLI fallback

```bash
uv run python -m chess_student_app.cli validate workspace/YOUR_NETID.py
uv run python -m chess_student_app.cli match --agent workspace/YOUR_NETID.py --opponent greedy --games 4
```

The local app listens only on `127.0.0.1`. Close the terminal window or press Ctrl+C to stop it.
