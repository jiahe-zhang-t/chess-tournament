from __future__ import annotations

import ast
import re
import sys
from pathlib import Path
from typing import Any

from chess_tournament_api import API_VERSION

from .agent_process import AgentProcess, AgentProcessError
from .controller import GameConfig
from .local_match import run_local_matchup

MAX_FILE_BYTES = 1_048_576
NETID_PATTERN = re.compile(r"[A-Za-z]{1,6}[0-9]{1,6}\Z")
DEVELOPMENT_EXAMPLE_STEMS = {"TEMPLATE_agent", "example_minimax"}
DENIED_IMPORT_ROOTS = {
    "ctypes",
    "ftplib",
    "http",
    "multiprocessing",
    "requests",
    "socket",
    "subprocess",
    "urllib",
}
ALLOWED_EXTERNAL_ROOTS = {"chess", "chess_tournament_api"}


def static_checks(path: str | Path) -> list[dict[str, Any]]:
    source = Path(path).resolve(strict=True)
    checks: list[dict[str, Any]] = []

    def add(name: str, passed: bool, detail: str) -> None:
        checks.append({"name": name, "passed": passed, "detail": detail})

    add("python_file", source.suffix.lower() == ".py", source.name)
    size = source.stat().st_size
    add("file_size", size <= MAX_FILE_BYTES, f"{size} bytes; limit {MAX_FILE_BYTES}")
    try:
        tree = ast.parse(source.read_text(encoding="utf-8"), filename=source.name)
    except (OSError, UnicodeError, SyntaxError) as exc:
        add("syntax", False, f"{type(exc).__name__}: {exc}")
        return checks
    add("syntax", True, "valid Python syntax")

    imported: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            imported.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imported.add(node.module.split(".", 1)[0])
    unknown = sorted(
        root
        for root in imported
        if root not in sys.stdlib_module_names and root not in ALLOWED_EXTERNAL_ROOTS
    )
    denied = sorted(root for root in imported if root in DENIED_IMPORT_ROOTS)
    add(
        "dependencies",
        not unknown and not denied,
        "approved imports" if not unknown and not denied else f"unknown={unknown}; prohibited={denied}",
    )
    filename_ok = bool(NETID_PATTERN.fullmatch(source.stem))
    if source.stem in DEVELOPMENT_EXAMPLE_STEMS:
        filename_detail = "development example only; copy or rename it to YOUR_NETID.py before submission"
    else:
        filename_detail = "valid NetID filename" if filename_ok else "use YOUR_NETID.py for submission"
    add("filename", filename_ok, filename_detail)
    return checks


def _validation_result(
    source: Path,
    checks: list[dict[str, Any]],
    *,
    games: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    development_passed = all(item["passed"] for item in checks if item["name"] != "filename")
    filename_check = next((item for item in checks if item["name"] == "filename"), None)
    submission_ready = development_passed and bool(filename_check and filename_check["passed"])
    development_example = source.stem in DEVELOPMENT_EXAMPLE_STEMS
    if submission_ready:
        status = "submission_ready"
    elif development_passed:
        status = "development_only"
    else:
        status = "failed"
    return {
        "submission": str(source),
        "api_version": API_VERSION,
        # Compatibility field: ``passed`` now means ready for official submission.
        "passed": submission_ready,
        "development_passed": development_passed,
        "submission_ready": submission_ready,
        "development_example": development_example,
        "status": status,
        "checks": checks,
        "games": games or [],
    }


def _student_fault_details(records: list[dict[str, Any]], student_id: str = "agent-a") -> list[str]:
    details: list[str] = []
    for record in records:
        result = record["result"]
        game_index = result["match_game_index"]
        initialization_fault = False
        for fault in record.get("initialization_faults", []):
            if fault.get("agent_id") == student_id:
                initialization_fault = True
                details.append(
                    f"game {game_index} initialize: {fault.get('category', 'initialize_failure')}"
                )
        if result.get("fault_agent_id") == student_id and not initialization_fault:
            category = str(result.get("termination_code") or "game_forfeit")
            callback = "initialize" if category.startswith("initialize") else "choose_move"
            details.append(f"game {game_index} {callback}: {category}")
        for fault in record.get("hook_faults", []):
            if fault.get("agent_id") == student_id:
                details.append(
                    f"game {game_index} on_game_end: {fault.get('category', 'on_game_end_failure')}"
                )
    return details


def validate_agent(path: str | Path) -> dict[str, Any]:
    source = Path(path).resolve(strict=True)
    checks = static_checks(source)
    if any(not item["passed"] for item in checks if item["name"] != "filename"):
        return _validation_result(source, checks)

    try:
        worker = AgentProcess(source, startup_timeout=2.0)
    except AgentProcessError as exc:
        checks.append({"name": "load_and_construct", "passed": False, "detail": f"{exc.category}: {exc}"})
        return _validation_result(source, checks)
    else:
        checks.append(
            {
                "name": "load_and_construct",
                "passed": True,
                "detail": f"{worker.class_name} as {worker.alias!r}",
            }
        )
        worker.close()

    config = GameConfig()
    all_records: list[dict[str, Any]] = []
    for opponent in ("random", "greedy"):
        try:
            records = run_local_matchup(
                source, opponent=opponent, games=2, base_seed=9100, config=config
            )
        except (AgentProcessError, OSError, ValueError) as exc:
            checks.append(
                {"name": f"games_vs_{opponent}", "passed": False, "detail": f"{type(exc).__name__}: {exc}"}
            )
            continue
        all_records.extend(records)
        student_faults = _student_fault_details(records)
        fault_detail = (
            "0 student faults"
            if not student_faults
            else f"{len(student_faults)} student fault(s): " + "; ".join(student_faults)
        )
        checks.append(
            {
                "name": f"games_vs_{opponent}",
                "passed": not student_faults,
                "detail": f"{len(records)} games; {fault_detail}",
            }
        )

    reproducible = False
    detail = "dynamic games did not complete"
    try:
        first = run_local_matchup(source, opponent="random", games=1, base_seed=4242, config=config)
        second = run_local_matchup(source, opponent="random", games=1, base_seed=4242, config=config)
        replay_faults = _student_fault_details(first) + _student_fault_details(second)
        if replay_faults:
            detail = "seeded replay could not be assessed: " + "; ".join(replay_faults)
        else:
            first_moves = first[0]["result"]["moves"]
            second_moves = second[0]["result"]["moves"]
            reproducible = True
            detail = (
                "same-seed replay completed with identical moves"
                if first_moves == second_moves
                else "same-seed replay completed; move identity may differ for clock-aware agents"
            )
    except (AgentProcessError, OSError, ValueError) as exc:
        detail = f"{type(exc).__name__}: {exc}"
    checks.append({"name": "seeded_replay", "passed": reproducible, "detail": detail})

    return _validation_result(source, checks, games=all_records)


def format_validation(result: dict[str, Any]) -> str:
    lines = [f"Submission: {result['submission']}", f"API version: {result['api_version']}", ""]
    for check in result["checks"]:
        status = "PASS" if check["passed"] else "FAIL"
        lines.append(f"[{status}] {check['name']}: {check['detail']}")
    if result["submission_ready"]:
        outcome = "PASSED — SUBMISSION READY"
    elif result["development_passed"]:
        outcome = "DEVELOPMENT CHECK PASSED — NOT SUBMISSION READY"
    else:
        outcome = "FAILED — NOT SUBMISSION READY"
    lines.extend(("", outcome))
    return "\n".join(lines)
