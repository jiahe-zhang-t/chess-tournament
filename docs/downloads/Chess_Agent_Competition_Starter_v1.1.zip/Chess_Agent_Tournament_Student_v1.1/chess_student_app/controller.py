from __future__ import annotations

import hashlib
import io
import math
import time
from dataclasses import dataclass
from typing import Any, Protocol

import chess
import chess.pgn

from chess_tournament_api import ChessAgent, GameResult, Observation

from .agent_process import AgentProcess, AgentProcessError


@dataclass(frozen=True, slots=True)
class GameConfig:
    initial_time: float = 30.0
    increment: float = 0.3
    choose_move_cap: float = 5.0
    initialize_cap: float = 1.0
    on_game_end_cap: float = 0.5
    max_plies: int = 500

    def validate(self) -> None:
        for name, value in (
            ("initial_time", self.initial_time),
            ("choose_move_cap", self.choose_move_cap),
            ("initialize_cap", self.initialize_cap),
            ("on_game_end_cap", self.on_game_end_cap),
        ):
            if not math.isfinite(value) or value <= 0:
                raise ValueError(f"{name} must be finite and positive")
        if not math.isfinite(self.increment) or self.increment < 0:
            raise ValueError("increment must be finite and nonnegative")
        if self.max_plies < 1:
            raise ValueError("max_plies must be positive")


class Endpoint(Protocol):
    alias: str
    alive: bool

    def initialize(self, payload: dict[str, Any], timeout: float) -> tuple[float, str]: ...
    def choose_move(self, observation: Observation, timeout: float) -> tuple[str, float, str]: ...
    def game_end(self, result: GameResult, timeout: float) -> tuple[float, str]: ...
    def close(self) -> None: ...


class WorkerEndpoint:
    def __init__(self, source: str, startup_timeout: float = 2.0) -> None:
        self.worker = AgentProcess(source, startup_timeout=startup_timeout)
        self.alias = self.worker.alias

    @property
    def alive(self) -> bool:
        return self.worker.alive

    def initialize(self, payload: dict[str, Any], timeout: float) -> tuple[float, str]:
        try:
            _, elapsed, logs = self.worker.rpc("initialize", payload, timeout=timeout)
            return elapsed, logs
        except AgentProcessError:
            self.worker.kill()
            raise

    def choose_move(self, observation: Observation, timeout: float) -> tuple[str, float, str]:
        try:
            value, elapsed, logs = self.worker.rpc(
                "choose_move", {"observation": observation.to_dict()}, timeout=timeout
            )
            return value, elapsed, logs
        except AgentProcessError:
            self.worker.kill()
            raise

    def game_end(self, result: GameResult, timeout: float) -> tuple[float, str]:
        try:
            _, elapsed, logs = self.worker.rpc("game_end", {"result": result.to_dict()}, timeout=timeout)
            return elapsed, logs
        except AgentProcessError:
            self.worker.kill()
            raise

    def close(self) -> None:
        self.worker.close()


class LocalEndpoint:
    def __init__(self, agent: ChessAgent) -> None:
        self.agent = agent
        self.alias = str(agent.name)

    @property
    def alive(self) -> bool:
        return True

    def initialize(self, payload: dict[str, Any], timeout: float) -> tuple[float, str]:
        started = time.monotonic()
        self.agent.initialize(
            color=payload["color"],
            opponent_id=payload["opponent_id"],
            time_control=tuple(payload["time_control"]),
            seed=payload["seed"],
        )
        return time.monotonic() - started, ""

    def choose_move(self, observation: Observation, timeout: float) -> tuple[str, float, str]:
        started = time.monotonic()
        move = self.agent.choose_move(observation)
        elapsed = time.monotonic() - started
        if elapsed > timeout:
            raise AgentProcessError("choose_move_timeout", "public agent exceeded callback cap")
        return move, elapsed, ""

    def game_end(self, result: GameResult, timeout: float) -> tuple[float, str]:
        started = time.monotonic()
        self.agent.on_game_end(result)
        return time.monotonic() - started, ""

    def close(self) -> None:
        return None


def stable_id(*parts: object, length: int = 16) -> str:
    payload = "\x1f".join(str(part) for part in parts).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()[:length]


def _pgn(
    board: chess.Board,
    *,
    white_alias: str,
    black_alias: str,
    result: str,
    termination: str,
    game_id: str,
    match_game_index: int,
    starting_fen: str,
) -> str:
    game = chess.pgn.Game.from_board(board)
    game.headers["Event"] = "Local Chess Agent Lab"
    game.headers["White"] = white_alias
    game.headers["Black"] = black_alias
    game.headers["Result"] = result
    game.headers["Termination"] = termination
    game.headers["GameID"] = game_id
    game.headers["Round"] = str(match_game_index)
    if starting_fen != chess.STARTING_FEN:
        game.headers["SetUp"] = "1"
        game.headers["FEN"] = starting_fen
    output = io.StringIO()
    print(game, file=output, end="\n\n")
    return output.getvalue()


def _scores(result: str) -> tuple[float, float]:
    if result == "1-0":
        return 1.0, 0.0
    if result == "0-1":
        return 0.0, 1.0
    if result == "1/2-1/2":
        return 0.5, 0.5
    if result == "*":
        return 0.0, 0.0
    raise ValueError(f"unsupported result {result}")


def _forfeit_result(color: chess.Color) -> str:
    return "0-1" if color == chess.WHITE else "1-0"


def play_game(
    white: Endpoint,
    black: Endpoint,
    *,
    white_id: str,
    black_id: str,
    white_opponent_id: str,
    black_opponent_id: str,
    match_id: str,
    match_game_index: int,
    seed: int,
    config: GameConfig,
    starting_fen: str = chess.STARTING_FEN,
) -> dict[str, Any]:
    config.validate()
    board = chess.Board(starting_fen)
    clocks = {chess.WHITE: config.initial_time, chess.BLACK: config.initial_time}
    endpoints = {chess.WHITE: white, chess.BLACK: black}
    ids = {chess.WHITE: white_id, chess.BLACK: black_id}
    opponent_ids = {chess.WHITE: white_opponent_id, chess.BLACK: black_opponent_id}
    moves: list[str] = []
    # ``move_times`` is retained as a flat compatibility view.  New consumers
    # should use ``move_callbacks``, which records whose callback was timed so
    # reports do not accidentally mix a student's timing with an opponent's.
    move_times: list[float] = []
    move_callbacks: list[dict[str, Any]] = []
    callback_logs: list[dict[str, str]] = []
    hook_faults: list[dict[str, str]] = []
    game_id = stable_id(match_id, match_game_index, seed, starting_fen)

    initialization_faults: dict[chess.Color, AgentProcessError] = {}
    initialization_fault_records: list[dict[str, str]] = []
    for color in (chess.WHITE, chess.BLACK):
        payload = {
            "color": "white" if color == chess.WHITE else "black",
            "opponent_id": opponent_ids[color],
            "time_control": [config.initial_time, config.increment],
            "seed": seed,
        }
        try:
            _, logs = endpoints[color].initialize(payload, config.initialize_cap)
            if logs:
                callback_logs.append({"agent_id": ids[color], "callback": "initialize", "text": logs})
        except AgentProcessError as exc:
            initialization_faults[color] = exc
            initialization_fault_records.append(
                {
                    "agent_id": ids[color],
                    "callback": "initialize",
                    "category": exc.category,
                }
            )

    if len(initialization_faults) == 2:
        result, termination, fault_id = "*", "double_forfeit", None
    elif len(initialization_faults) == 1:
        failed_color = next(iter(initialization_faults))
        result = _forfeit_result(failed_color)
        termination = initialization_faults[failed_color].category
        fault_id = ids[failed_color]
    else:
        result = ""
        termination = ""
        fault_id = None

    while not result and not board.is_game_over(claim_draw=True):
        if len(moves) >= config.max_plies:
            result, termination = "1/2-1/2", "maximum_plies"
            break
        color = board.turn
        opponent = not color
        observation = Observation(
            fen=board.fen(),
            move_history=tuple(moves),
            my_remaining_time=clocks[color],
            opponent_remaining_time=clocks[opponent],
            increment=config.increment,
            color="white" if color == chess.WHITE else "black",
            opponent_id=opponent_ids[color],
            match_game_index=match_game_index,
            seed=seed,
        )
        deadline = min(config.choose_move_cap, max(0.001, clocks[color]))
        try:
            move_text, elapsed, logs = endpoints[color].choose_move(observation, deadline)
            if logs:
                callback_logs.append({"agent_id": ids[color], "callback": "choose_move", "text": logs})
        except AgentProcessError as exc:
            result = _forfeit_result(color)
            termination = (
                "clock_timeout"
                if exc.category == "choose_move_timeout"
                and clocks[color] <= config.choose_move_cap
                else exc.category
            )
            fault_id = ids[color]
            break

        clocks[color] -= elapsed
        move_times.append(elapsed)
        move_callbacks.append(
            {
                "agent_id": ids[color],
                "color": "white" if color == chess.WHITE else "black",
                "ply": len(moves) + 1,
                "elapsed_seconds": elapsed,
            }
        )
        if clocks[color] < 0:
            result = _forfeit_result(color)
            termination = "clock_timeout"
            fault_id = ids[color]
            break
        if type(move_text) is not str:
            result = _forfeit_result(color)
            termination = "invalid_output"
            fault_id = ids[color]
            break
        try:
            move = chess.Move.from_uci(move_text.strip())
        except ValueError:
            move = None
        if move is None or move not in board.legal_moves:
            result = _forfeit_result(color)
            termination = "illegal_move"
            fault_id = ids[color]
            break
        moves.append(move.uci())
        board.push(move)
        clocks[color] += config.increment

    if not result:
        outcome = board.outcome(claim_draw=True)
        if outcome is None:
            result, termination = "1/2-1/2", "unknown_adjudication"
        else:
            result = outcome.result()
            termination = outcome.termination.name.lower()

    white_score, black_score = _scores(result)
    result_record = {
        "game_id": game_id,
        "match_id": match_id,
        "white_id": white_id,
        "black_id": black_id,
        "white_alias": white.alias,
        "black_alias": black.alias,
        "result": result,
        "white_score": white_score,
        "black_score": black_score,
        "termination_code": termination,
        "fault_agent_id": fault_id,
        "moves": list(moves),
        "white_time": max(0.0, clocks[chess.WHITE]),
        "black_time": max(0.0, clocks[chess.BLACK]),
        "starting_fen": starting_fen,
        "seed": seed,
        "match_game_index": match_game_index,
        "pgn": _pgn(
            board,
            white_alias=white.alias,
            black_alias=black.alias,
            result=result,
            termination=termination,
            game_id=game_id,
            match_game_index=match_game_index,
            starting_fen=starting_fen,
        ),
    }

    def agent_result(color: chess.Color) -> GameResult:
        mine = white_score if color == chess.WHITE else black_score
        theirs = black_score if color == chess.WHITE else white_score
        if mine > theirs:
            outcome = "win"
        elif mine < theirs:
            outcome = "loss"
        else:
            outcome = "draw"
        if fault_id is None:
            fault_side = None
        elif fault_id == ids[color]:
            fault_side = "self"
        else:
            fault_side = "opponent"
        return GameResult(
            game_id=game_id,
            opponent_id=opponent_ids[color],
            my_color="white" if color == chess.WHITE else "black",
            outcome=outcome,
            my_score=mine,
            opponent_score=theirs,
            termination_code=termination,
            fault_side=fault_side,
            moves=tuple(moves),
            my_remaining_time=max(0.0, clocks[color]),
            opponent_remaining_time=max(0.0, clocks[not color]),
            starting_fen=starting_fen,
            seed=seed,
            match_game_index=match_game_index,
        )

    for color in (chess.WHITE, chess.BLACK):
        if color in initialization_faults or not endpoints[color].alive:
            continue
        try:
            _, logs = endpoints[color].game_end(agent_result(color), config.on_game_end_cap)
            if logs:
                callback_logs.append({"agent_id": ids[color], "callback": "on_game_end", "text": logs})
        except AgentProcessError as exc:
            hook_faults.append({"agent_id": ids[color], "category": exc.category})

    return {
        "result": result_record,
        "move_times": move_times,
        "move_callbacks": move_callbacks,
        "callback_logs": callback_logs,
        "initialization_faults": initialization_fault_records,
        "hook_faults": hook_faults,
    }
